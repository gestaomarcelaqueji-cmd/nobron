import { siteConfig } from "@/data/site";

import type {
  HeroAmbientWord,
  HeroPhase,
  HeroSolution,
  HeroSolutionId,
} from "./heroImmersive.types";

export const HERO_PHASE_ORDER: readonly HeroPhase[] = [
  "intro",
  "network-points",
  "network-connections",
  "observing",
  "portals",
  "interactive",
  "route-exit",
] as const;

export const HERO_PHASE_DELAYS = {
  "network-points": 0,
  "network-connections": 680,
  observing: 1_480,
  portals: 2_350,
  interactive: 4_450,
} as const satisfies Partial<Record<HeroPhase, number>>;

export const HERO_SOLUTIONS = [
  {
    id: "landing-page",
    label: "Landing Page",
    shortLabel: "Landing Page",
    description: `Uma página estratégica, publicada e mantida pela noBRon a partir de R$ ${siteConfig.price} por mês.`,
    href: "/landing-page",
    ambientLabel: "conversão",
    featured: true,
    order: 0,
    nodeIndex: 0,
    fallback: {
      desktop: { x: 55, y: 42 },
      mobile: { x: 50, y: 34 },
    },
  },
  {
    id: "brand",
    label: "Marca e identidade visual",
    shortLabel: "Marca",
    description:
      "Uma identidade coerente para tornar o seu negócio reconhecível em cada ponto de contato.",
    href: "/solucoes/marca-identidade-visual",
    ambientLabel: "design",
    featured: false,
    order: 1,
    nodeIndex: 5,
    fallback: {
      desktop: { x: 22, y: 29 },
      mobile: { x: 20, y: 26 },
    },
  },
  {
    id: "sites",
    label: "Sites e presença digital",
    shortLabel: "Sites",
    description:
      "Estruturas digitais claras, responsivas e preparadas para apresentar seu negócio.",
    href: "/solucoes/sites-presenca-digital",
    ambientLabel: "presença",
    featured: false,
    order: 2,
    nodeIndex: 13,
    fallback: {
      desktop: { x: 79, y: 28 },
      mobile: { x: 80, y: 26 },
    },
  },
  {
    id: "content",
    label: "Conteúdo e redes sociais",
    shortLabel: "Conteúdo",
    description:
      "Conteúdo com direção para comunicar valor e manter sua marca presente nas redes.",
    href: "/solucoes/conteudo-redes-sociais",
    ambientLabel: "conteúdo",
    featured: false,
    order: 3,
    nodeIndex: 21,
    fallback: {
      desktop: { x: 18, y: 63 },
      mobile: { x: 18, y: 54 },
    },
  },
  {
    id: "growth",
    label: "Divulgação e crescimento",
    shortLabel: "Crescimento",
    description:
      "Campanhas e caminhos de aquisição conectados aos objetivos reais do negócio.",
    href: "/solucoes/divulgacao-crescimento",
    ambientLabel: "marketing",
    featured: false,
    order: 4,
    nodeIndex: 29,
    fallback: {
      desktop: { x: 81, y: 64 },
      mobile: { x: 82, y: 54 },
    },
  },
  {
    id: "systems",
    label: "Sistemas e automações",
    shortLabel: "Sistemas",
    description:
      "Fluxos, integrações e ferramentas que reduzem tarefas repetitivas e organizam a operação.",
    href: "/solucoes/sistemas-automacoes",
    ambientLabel: "automação",
    featured: false,
    order: 5,
    nodeIndex: 37,
    fallback: {
      desktop: { x: 50, y: 74 },
      mobile: { x: 50, y: 61 },
    },
  },
] as const satisfies readonly HeroSolution[];

export const HERO_SOLUTIONS_BY_ID = Object.fromEntries(
  HERO_SOLUTIONS.map((solution) => [solution.id, solution]),
) as Record<HeroSolutionId, (typeof HERO_SOLUTIONS)[number]>;

export const HERO_AMBIENT_WORDS = [
  { label: "estratégia", x: 35, y: 22 },
  { label: "design", x: 68, y: 20 },
  { label: "marketing", x: 67, y: 77 },
  { label: "automação", x: 31, y: 79 },
] as const satisfies readonly HeroAmbientWord[];

export const HERO_NAV_ITEMS = [
  { label: "Soluções", href: "#mapa-de-solucoes" },
  { label: "Landing Page", href: "/landing-page" },
  { label: "Projeto", href: "/prototipo-gratuito" },
] as const;

